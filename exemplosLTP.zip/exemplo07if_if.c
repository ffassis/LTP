    if(n1 == n2)
        printf("Os n�meros s�o iguais!");
    if(n1 > n2)
        printf("O n�mero 1 � o maior!");


    if(n1 == n2)
        printf("Os n�meros s�o iguais!");
    else if(n1 > n2)
        printf("O n�mero 1 � o maior!");
    else
        printf("O n�mero 2 � o maior!");
