//programa que imprime o vencedor entre dois jogadores
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i, num, cont=0, jogador1=0, jogador2=0;
    int jog1[3], jog2[3];

    printf("Jogo da Verdade - Quem Passa Joga e Quem Joga Passa!\n");

    for(i=0; i<=2; i++){
        printf("Jogador 1. Digite a %d� jogada: ", i);
        scanf("%d", &jog1[i]);
        jogador1 = jogador1 + jog1[i];
    }

    for(i=0; i<=2; i++){
        printf("Jogador 2. Digite a %d� jogada: ", i);
        scanf("%d", &jog2[i]);
        jogador2 = jogador2 + jog2[i];
    }

    printf("Pontua��o individual:\n");
    for(i=0; i<=2; i++){
        printf("Jogador 1: %d Jogador 2: %d\n", jog1[i], jog2[i]);
    }

    if(jogador1 == jogador2)
        printf("Empate!");
    else if(jogador1 > jogador2)
        printf("Jogador 1 Vencedor!");
    else
        printf("Jogador 2 Vencedor!");

    return 0;
}

