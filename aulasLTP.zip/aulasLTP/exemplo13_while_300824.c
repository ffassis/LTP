#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");
    int i=0;

    while(i <= 10){
        if(i < 10)
            printf("%d, ", i);
        else
            printf("%d.", i);

        i++;
    }
    return 0;
}

