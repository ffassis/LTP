#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i=0, v[5];

    while(i < 4){
            v[i] = 5;
        printf("%d ", i);

        i++;

    }

    return 0;
}
