//programa que imprime os m�ltiplos de um n�mero
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i, num;

    printf("Digite um n�mero: ");
    scanf("%d", &num);

    for(i=1; i<=num; i++){
        if(num % i == 0){
            printf("%d ", i);
        }

    }

    return 0;
}
