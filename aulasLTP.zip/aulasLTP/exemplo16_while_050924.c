//fa�a um programa que leia um n�mero inteiro e o imprima
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numero=0, soma=0, i=0, n=0;

    while(i < 4){
            i++;
        //printf("Digite um n�mero: ");
        //scanf("%d", &numero);

        soma = soma + numero;

        printf("i = %d, n = %d\n", i, n);


    }


    printf("Soma: %d", soma);

    return 0;
}
