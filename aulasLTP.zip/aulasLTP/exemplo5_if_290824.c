#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");
    int nota1, nota2, nota3, nota4, nota5;
    float media;

    printf("Digite 5 notas : ");
    scanf("%d %d %d %d %d", &nota1, &nota2, &nota3, &nota4, &nota5);

    media = (nota1 + nota2 + nota3 + nota4 + nota5)/5.0;

    printf("M�dia: %.1f. ", media);

    if(media >= 7){
        printf("Aprovado!");
    }
    else{
        printf("Reprovado!");
    }

    return 0;
}
