#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");
    int i=0;

    while(i < 100){
        if(i%2 == 1)
            printf("N�mero %d � �mpar\n", i);

        i++;
    }
    return 0;
}
