//programa que imprime o vencedor entre dois jogadores
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i, num, cont=0, jogador1=0, jogador2=0;

    printf("Jogo da Verdade - Quem Passa Joga e Quem Joga Passa!\n");

    for(i=1; i<=3; i++){
        printf("Jogador 1. Digite a %d� jogada: ", i);
        scanf("%d", &num);
        jogador1 = jogador1 + num;
    }

    for(i=1; i<=3; i++){
        printf("Jogador 2. Digite a %d� jogada: ", i);
        scanf("%d", &num);
        jogador2 = jogador2 + num;
    }

    if(jogador1 == jogador2)
        printf("Empate!");
    else if(jogador1 > jogador2)
        printf("Jogador 1 Vencedor!");
    else
        printf("Jogador 2 Vencedor!");

    return 0;
}

