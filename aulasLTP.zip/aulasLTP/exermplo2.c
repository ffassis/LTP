#include <stdio.h>

int main() {
    int nota1=0, nota2=0, nota3=0;
    float media=0.0;

    printf("Digite a nota 1: ");
    scanf("%d", &nota1);

    printf("Digite a nota 2: ");
    scanf("%d", &nota2);

    printf("Digite a nota 3: ");
    scanf("%d", &nota3);

    media = (nota1+nota2+nota3)/3;

    printf("M�dia do aluno: %.1f", media);

    if(media > 7)
        printf(" Aluno, aprovado!");
    else
        printf(" Aluno, reprovado!");

    return 0;
}
