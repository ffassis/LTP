#include <stdio.h>
#include <locale.h>
int main(){
    setlocale(LC_ALL, "portuguese");
    float nota1, nota2, nota3, media;

    printf("Digite tr�s notas:\n");
    scanf("%f %f %f", &nota1, &nota2, &nota3);

    media = (nota1+nota2+nota3)/3;

    if(media >= 7)
        printf("M�dia: %.2f - Aluno Aprovado!", media);
    else if(media >= 4)
        printf("M�dia: %.2f - Aluno em Exame!", media);
    else
        printf("M�dia: %.2f - Aluno Reprovado!", media);

    return 0;
}
