#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");
    int i=0, n;

    printf("Digite um n�mero: ");
    scanf("%d", &n);

    while(i <= 10){
        printf("%d x %d = %d\n", n, i, n*i);

        i++;
    }
    return 0;
}
