#include <stdio.h>

int main(){
    int i=0;

    while(i <= 10000){
        printf("%d ", i);
        i++;
    }

    return 0;
}
