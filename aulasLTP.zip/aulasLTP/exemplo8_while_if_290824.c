#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i=0;

    while(i <= 100){
            if(i%3 == 0)
                printf("%d o n�mero � M�ltiplo de 3\n", i);

        i++;
    }

    return 0;
}
