//programa que imprime se um determinado n�mero � primo
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i, num, cont=0;

    printf("Digite um n�mero: ");
    scanf("%d", &num);

    for(i=1; i<=num; i++){
        if(num % i == 0){
            cont++;
        }
    }

    if(cont <=2 )
        printf("%d � primo!", num);
    else
        printf("%d N�O � primo!", num);

    return 0;
}
