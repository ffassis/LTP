#include <stdio.h>

int main(){
    int nota1, nota2, nota3, nota4, nota5;
    float media;

    printf("Digite a nota 1: ");
    scanf("%d", &nota1);

    printf("Digite a nota 2: ");
    scanf("%d", &nota2);

    printf("Digite a nota 3: ");
    scanf("%d", &nota3);

    printf("Digite a nota 4: ");
    scanf("%d", &nota4);

    printf("Digite a nota 5: ");
    scanf("%d", &nota5);

    media = (nota1 + nota2 + nota3 + nota4 + nota5)/5;

    if(media >= 7)
        printf("Aprovado!");
    else
        printf("Reprovado!");

    return 0;
}
