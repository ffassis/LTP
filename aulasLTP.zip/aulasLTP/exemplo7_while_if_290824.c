#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "Portuguese");
    int i=0;

    while(i <= 100){
            if(i%2 == 0)
                printf("%d n�mero par\n", i);
            else
                printf("%d n�mero �mpar\n", i);
        i++;
    }

    return 0;
}
