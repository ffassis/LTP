//7
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numeroDigitado=0, i=1, j=1;

    printf("Digite um n�mero: ");
    scanf("%d", &numeroDigitado);//3

    for(i=1; i <= numeroDigitado; i++){
        for(j=1; j <= i; j++){
            printf("* ");
        }
        printf("\n");
    }

    return 0;
}

