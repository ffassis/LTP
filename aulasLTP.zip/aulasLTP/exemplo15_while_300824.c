#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");
    int i=0, j=0;

    while(i <= 10){
        j=0;
        while(j <= 10){
            printf("%d ", j);

            j++;
        }

        printf("\n");
        i++;
    }
    return 0;
}

