//exerc�cio 7, fa�a um programa que imprime
/*
1
2 2
3 3 3
4 4 4 4
*/

#include <stdio.h>

int main(){
    int n, i=1, j=1;

    printf("Digite um n�mero: ");
    scanf("%d", &n);
/*
    printf("exemplo com For\n");
    for(i=1; i <= n; i++){
        for(j=1; j<=i; j++){
            printf("%d ", i);
        }
        printf("\n");
    }
*/
/*
    i=1;
    printf("exemplo com While\n");
    while(i <= n){
        j=1;4
        while(j<=i){
            printf("%d ", i);
            j++;
        }
        printf("\n");
        i++;
    }

*/

       printf("exemplo com While\n");
    do{
        j=1;
        do{
            printf("%d ", i);
            j++;
        }while(j<=i);
        printf("\n");
        i++;
    }while(i <= n);

    return 0;

}
