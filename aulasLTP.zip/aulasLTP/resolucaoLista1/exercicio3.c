//3 lista
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int senhaCadastrada, senhaDigitada;
    printf("Cadastre uma senha: ");
    scanf("%d", &senhaCadastrada);

    printf("\nAcesso ao sistema.\nDigite sua senha cadastrada: ");
    scanf("%d", &senhaDigitada);

    if(senhaCadastrada == senhaDigitada)
        printf("\nAcesso permitido!");
    else
        printf("\nAcesso Negado, senha incorreta!");

    return 0;
}

