//exerc�cio 7, fa�a um programa que imprime
/*
1
2 2
3 3 3
4 4 4 4
*/

#include <stdio.h>

int main(){
    int n, i=1, j=1;

    printf("Digite um n�mero: ");
    scanf("%d", &n);

    printf("exemplo com While\n");
    while(i <= n){
        while(j<=i){
            printf("%d ", i);
            j++;
        }
        printf("\n");
        i++;
    }
    return 0;

}
