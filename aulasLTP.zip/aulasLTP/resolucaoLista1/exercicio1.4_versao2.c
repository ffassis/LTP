//1.4 leia um n�mero real e imprima o resultado do quadrado
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    float numero, potencia;

    printf("Digite um n�mero: ");
    scanf("%f", &numero);

    potencia = numero*numero;

    printf("N�mero ao quadrado: %.0f", potencia);

    return 0;
}

