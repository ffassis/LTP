//5 Escreva um algoritmo que exibe todos os divisores de um n�mero fornecido pelo usu�rio. ex 4 = 1 2 4
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numeroDigitado, i=1;

    printf("Digite um n�mero: ");
    scanf("%d", &numeroDigitado);

    while(i != numeroDigitado){
        if(numeroDigitado%i == 0)
            printf("%d ", i);

        i++;
    }

    return 0;
}

