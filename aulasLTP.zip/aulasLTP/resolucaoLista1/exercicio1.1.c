//fa�a um programa que leia um n�mero inteiro e o imprima
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numero=0;

    printf("Digite um n�mero: ");
    scanf("%d", &numero);

    printf("N�mero digitado foi: %d", numero);

    return 0;
}
