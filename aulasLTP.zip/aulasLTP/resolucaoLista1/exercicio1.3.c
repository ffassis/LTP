//1.3 pe�a ao usu�rio para digitar tr�s valores inteiros e imprima a soma
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numero1, numero2, numero3, soma;

    printf("Digite o n�mero 1: ");
    scanf("%d", &numero1);

    printf("Digite o n�mero 2: ");
    scanf("%d", &numero2);

    printf("Digite o n�mero 3: ");
    scanf("%d", &numero3);

    soma = numero1+numero2+numero3;

    printf("Soma: %d", soma);

    return 0;
}
