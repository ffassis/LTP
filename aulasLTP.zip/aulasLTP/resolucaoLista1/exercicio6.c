//6 Escreva um algoritmo que exibe todos os divisores de um n�mero fornecido pelo usu�rio. ex 4 = 1 2 4
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numeroDigitado=0, i=0, tabuada=0;

    printf("Digite um n�mero: ");
    scanf("%d", &numeroDigitado);

    while(i < 10){
        //printf("%d x %d = %d\n", numeroDigitado, i, numeroDigitado*i);
        tabuada = numeroDigitado*i;
        printf("%d x %d = %d\n", numeroDigitado, i, tabuada);
        i++;
    }

    printf("\ni = %d", i);
    return 0;
}

