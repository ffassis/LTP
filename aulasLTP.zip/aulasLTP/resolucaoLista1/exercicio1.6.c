//1.6 leia um valor em real e a cota��o do d�lar imoprima o valor em d�lar
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    float valorReal, valorDolar, cotacaoEmDolar;

    printf("Funcion�rio cadastre a cota��o do d�lar ($): ");
    scanf("%f", &valorDolar);

    printf("Cliente informe quanto voc� tem em reais R$: ");
    scanf("%f", &valorReal);

    cotacaoEmDolar = valorReal/valorDolar;

    printf("Voc� ir� receber em dolares: $ %.2f", cotacaoEmDolar);

    return 0;
}

