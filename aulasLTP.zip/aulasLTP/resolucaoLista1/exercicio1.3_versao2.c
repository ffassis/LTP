//1.3 pe�a ao usu�rio para digitar tr�s valores inteiros e imprima a soma
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numero1, numero2, numero3, soma;

    printf("Digite tr�s n�meros:\n");
    scanf("%d %d %d", &numero1, &numero2, &numero3);

    soma = numero1+numero2+numero3;

    printf("Soma: %d", soma);

    return 0;
}
