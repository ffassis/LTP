//4 lista
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int a=15, b=2;
    int c;

    c = 2 + 3 * b - 4 % 3 * a;

        //2 + (3 * b) - ((4 % 3) * a)
       // 2 + (3 * 2) - ((4 % 3) * 15)
       // 2 + 6 - (1 * 15)
       // 2 + 6 - 15 = -7

        //2 + (3 * b) - ((4 % 3) * a);
        //2 + 30 - (1 * 25)
        //2 + 30 - 25 = 7

    printf("C: %d", c);

    return 0;
}

