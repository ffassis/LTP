//1.5 leia quatro notas, calcule e imprima a m�dia
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int nota1, nota2, nota3, nota4;
    float media;

    printf("Digite a nota 1: ");
    scanf("%d", &nota1);
    printf("Digite a nota 2: ");
    scanf("%d", &nota2);
    printf("Digite a nota 3: ");
    scanf("%d", &nota3);
    printf("Digite a nota 4: ");
    scanf("%d", &nota4);

    media = (nota1+nota2+nota3+nota4)/4.0;

    printf("M�dia do aluno: %.2f", media);

    return 0;
}


