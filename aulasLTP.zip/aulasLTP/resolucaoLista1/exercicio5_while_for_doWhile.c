//escreva um programa que exibe todos os divisores  de um n�mero
//la�o while e for, precisam de uma vari�vel de inicializa��o
//a vari�vel de controle precisa ser modificada para que em algum momento o la�o termine
//para o la�o for e while ser executado, o teste da condi��o precisa ser verdadeiro (1)

#include <stdio.h>

int main(){
    int numDigitado=5, i=1;

    printf("Digite um n�mero: ");
    scanf("%d", &numDigitado);

    for(i=1; i <= numDigitado; i++){
        if(numDigitado % i == 0)
           printf("%d ", i);
    }
/*
    while(i <= numDigitado){
        if(numDigitado % i == 0)
           printf("%d ", i);
        i++;
    }
*/
/*
    do{
        if(numDigitado % i == 0)
           printf("%d ", i);
        i++;
    }while(i <= numDigitado);
*/
    return 0;

}
