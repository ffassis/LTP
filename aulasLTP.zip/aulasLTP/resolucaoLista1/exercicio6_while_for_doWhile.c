//exerc�cio 6, fa�a um programa que imprime a tabuada

#include <stdio.h>

int main(){
    int n, i=0;

    printf("Digite um n�mero: ");
    scanf("%d", &n);

    printf("Tabuada com For\n");
    for(i=0; i <= 10; i++){
           printf("%d x %d = %d \n", n, i, n*i);
    }

    i=0;
    printf("Tabuada com While\n");
    while(i <= 10){
        printf("%d x %d = %d \n", n, i, n*i);
        i++;
    }


 printf("Tabuada com do While\n");
    do{
        printf("%d x %d = %d \n", n, i, n*i);
        i++;
    }while(i <= 10);

    return 0;

}
