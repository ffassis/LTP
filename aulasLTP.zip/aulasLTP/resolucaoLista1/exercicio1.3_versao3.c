//1.3 pe�a ao usu�rio para digitar tr�s valores inteiros e imprima a soma
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numero1, numero2, numero3, soma=0, i=0, potencia=0;

    while(i < 3){
        printf("Digite um n�mero:\n");
        scanf("%d", &numero1);
        numero1 = numero1 * numero1;

        potencia = potencia + numero1;

        i++;
    }

    printf("Soma: %d", potencia);

    return 0;
}
