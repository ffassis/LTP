//7
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numeroDigitado=0, i=1, j=1;

    printf("Digite um n�mero: ");
    scanf("%d", &numeroDigitado);//3

    while(i <= numeroDigitado){
        while(j <= i){
            printf("%d ", i);

            j++;
        }
        j=1;
        printf("\n");
        i++;
    }

    return 0;
}

