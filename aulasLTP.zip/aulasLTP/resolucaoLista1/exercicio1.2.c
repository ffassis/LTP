//1.2 fa�a um programa que leia um n�mero real e o imprima
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    float numero;

    printf("Digite um n�mero: ");
    scanf("%f", &numero);

    printf("N�mero digitado foi: %.3f", numero);

    return 0;
}
