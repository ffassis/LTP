//1.7 leia um um n�mero inteiro e imprima o seu antecessor e seu sucessor
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int n, s;
    printf("Cadastre uma senha: ");
    scanf("%d", &n);

    printf("\nAcesso ao sistema. digite sua senha cadastrada: ");
    scanf("%d", &s);

    if(n == s)
        printf("\nAcesso permitido!");

    else
        printf("\nAcesso Negado, senha incorreta!");

    return 0;
}

