//1.7 leia um um n�mero inteiro e imprima o seu antecessor e seu sucessor
#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int n;

    printf("Digite um n�mero: ");
    scanf("%d", &n);

    printf("N�mero digitado: %d. Antecessor: %d, Sucessor: %d", n, n-1, n+1);

    return 0;
}

