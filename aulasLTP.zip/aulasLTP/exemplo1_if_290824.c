#include <stdio.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, "portuguese");

    int numero1=0, numero2=0;

    printf("Digite dois n�meros: ");
    scanf("%d %d", &numero1, &numero2);

    if(numero1 == numero2){
        printf("N�meros iguais");
    }
    else if(numero1 > numero2){
        printf("N�mero 1 � o maior!");
    }
    else{
        printf("N�mero 2 � o maior!");
    }

    return 0;
}
