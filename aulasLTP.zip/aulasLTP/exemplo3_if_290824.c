#include <stdio.h>

int main(){
    int nota1, nota2, nota3, nota4, nota5;
    float media;

    printf("Digite 5 notas : ");
    scanf("%d", &nota1);
    scanf("%d", &nota2);
    scanf("%d", &nota3);
    scanf("%d", &nota4);
    scanf("%d", &nota5);

    media = (nota1 + nota2 + nota3 + nota4 + nota5)/5;

    if(media >= 7)
        printf("Aprovado!");
    else
        printf("Reprovado!");

    return 0;
}
